/* Compact SHA-256 (synchronous, dependency-free) + helpers */
const sha256 = (function () {
  function rrot(x, n) { return (x >>> n) | (x << (32 - n)); }
  const K = [
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  return function (ascii) {
    const bytes = []; for (let i = 0; i < ascii.length; i++) {
      let c = ascii.charCodeAt(i);
      if (c < 128) bytes.push(c);
      else if (c < 2048) { bytes.push(192 | (c >> 6), 128 | (c & 63)); }
      else { bytes.push(224 | (c >> 12), 128 | ((c >> 6) & 63), 128 | (c & 63)); }
    }
    let H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    const l = bytes.length * 8; bytes.push(0x80);
    while (bytes.length % 64 !== 56) bytes.push(0);
    for (let i = 7; i >= 0; i--) bytes.push((l / Math.pow(2, i * 8)) & 0xff);
    const w = new Array(64);
    for (let j = 0; j < bytes.length; j += 64) {
      for (let i = 0; i < 16; i++)
        w[i] = (bytes[j+i*4]<<24)|(bytes[j+i*4+1]<<16)|(bytes[j+i*4+2]<<8)|(bytes[j+i*4+3]);
      for (let i = 16; i < 64; i++) {
        const s0 = rrot(w[i-15],7)^rrot(w[i-15],18)^(w[i-15]>>>3);
        const s1 = rrot(w[i-2],17)^rrot(w[i-2],19)^(w[i-2]>>>10);
        w[i] = (w[i-16]+s0+w[i-7]+s1)|0;
      }
      let [a,b,c,d,e,f,g,h] = H;
      for (let i = 0; i < 64; i++) {
        const S1 = rrot(e,6)^rrot(e,11)^rrot(e,25);
        const ch = (e&f)^(~e&g);
        const t1 = (h+S1+ch+K[i]+w[i])|0;
        const S0 = rrot(a,2)^rrot(a,13)^rrot(a,22);
        const maj = (a&b)^(a&c)^(b&c);
        const t2 = (S0+maj)|0;
        h=g; g=f; f=e; e=(d+t1)|0; d=c; c=b; b=a; a=(t1+t2)|0;
      }
      H = [(H[0]+a)|0,(H[1]+b)|0,(H[2]+c)|0,(H[3]+d)|0,(H[4]+e)|0,(H[5]+f)|0,(H[6]+g)|0,(H[7]+h)|0];
    }
    return H.map((x) => (x >>> 0).toString(16).padStart(8, "0")).join("");
  };
})();

/* password strength: returns {bits, score 0-4, label, crack} */
function strength(pw) {
  if (!pw) return { bits: 0, score: 0, label: "empty", crack: "—" };
  let pool = 0;
  if (/[a-z]/.test(pw)) pool += 26;
  if (/[A-Z]/.test(pw)) pool += 26;
  if (/[0-9]/.test(pw)) pool += 10;
  if (/[^a-zA-Z0-9]/.test(pw)) pool += 33;
  const bits = Math.round(pw.length * Math.log2(pool || 1));
  const guesses = Math.pow(2, bits) / 2;
  const secs = guesses / 1e10; // 10B guesses/sec offline
  const crack = humanTime(secs);
  let score = 0;
  if (bits >= 28) score = 1;
  if (bits >= 40) score = 2;
  if (bits >= 60) score = 3;
  if (bits >= 80) score = 4;
  const labels = ["very weak", "weak", "okay", "strong", "very strong"];
  return { bits, score, label: labels[score], crack };
}
function humanTime(s) {
  if (s < 1) return "instantly";
  const u = [["years",31557600],["days",86400],["hours",3600],["minutes",60],["seconds",1]];
  for (const [n, k] of u) {
    if (s >= k) {
      const v = s / k;
      if (n === "years" && v > 1e6) return v > 1e12 ? "longer than the universe" : `${(v/1e6).toFixed(0)}M years`;
      return `${v < 10 ? v.toFixed(1) : Math.round(v).toLocaleString()} ${n}`;
    }
  }
  return "instantly";
}

Object.assign(window, { sha256, strength, humanTime });
